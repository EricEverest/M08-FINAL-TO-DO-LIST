package com.example.todolistapp

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.example.todolist.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val createTaskButton: Button = findViewById(R.id.createTaskButton)
        val helpIcon: ImageView = findViewById(R.id.helpIcon)
        val helpText: TextView = findViewById(R.id.helpText)
        val preferencesText: TextView = findViewById(R.id.preferencesText)

        createTaskButton.setOnClickListener {
        }

        helpIcon.setOnClickListener {
        }

        helpText.setOnClickListener {
        }

        preferencesText.setOnClickListener {
            val currentTheme = resources.configuration.uiMode and
                    android.content.res.Configuration.UI_MODE_NIGHT_MASK
            if (currentTheme == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
        }
    }
}
